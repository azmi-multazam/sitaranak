package com.zam.sidik_padang.roodiskusi;

public interface OnItemLongClickListener {

    public void onItemLongClick(Object o, int position);
}
