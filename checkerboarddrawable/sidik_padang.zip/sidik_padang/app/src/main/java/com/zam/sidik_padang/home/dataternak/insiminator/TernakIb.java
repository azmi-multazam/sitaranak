package com.zam.sidik_padang.home.dataternak.insiminator;

import java.io.Serializable;

/**
 * Created by supriyadi on 4/17/18.
 */

public class TernakIb implements Serializable {
    public String id, id_ternak, jenis, bangsa, id_bangsa, kelamin, umur, bulan, hari, id_pemilik, nama,
            tanggal_ib, no_irtek, no_straw, tanggal_pkb, kondisi_ternak, kondisi_warna = "#cccccc";
}
