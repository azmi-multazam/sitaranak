package com.zam.sidik_padang;

/**
 * Created by supriyadi on 4/17/18.
 */

public class BaseApiResponse {
    public boolean success = false;
    public String message = "Terjadi kesalahan 5123";
}
