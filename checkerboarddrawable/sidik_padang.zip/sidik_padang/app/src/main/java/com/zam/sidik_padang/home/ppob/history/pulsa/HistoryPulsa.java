package com.zam.sidik_padang.home.ppob.history.pulsa;

public class HistoryPulsa {
    public String id = "", produk = "", status = "";
}


/*
{"history_pulsa":[{"id":"689",
			       "produk":"S10 081396641249 Trx Via Android",
				   "status":"Gagal"
				   },
				   
				   */
