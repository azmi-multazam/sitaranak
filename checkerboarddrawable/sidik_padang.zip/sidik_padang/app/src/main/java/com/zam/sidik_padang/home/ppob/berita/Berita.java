package com.zam.sidik_padang.home.ppob.berita;

/**
 * Created by supriyadi on 8/11/17.
 */

public class Berita {
    public int id, hits = 0;
    public String tanggal = "", title = "", isi = "";
    boolean collapsed = true;
}
