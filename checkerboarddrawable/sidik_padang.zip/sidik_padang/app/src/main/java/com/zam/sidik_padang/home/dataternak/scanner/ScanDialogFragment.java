package com.zam.sidik_padang.home.dataternak.scanner;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.ResultPoint;
import com.google.zxing.client.android.BeepManager;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;
import com.journeyapps.barcodescanner.DefaultDecoderFactory;

import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.zam.sidik_padang.R;
import com.zam.sidik_padang.databinding.FragmentScanDialogBinding;

/**
 * <p>A fragment that shows a list of items as a modal bottom sheet.</p>
 * <p>You can show this modal bottom sheet from your activity like this:</p>
 * <pre>
 *     ScanDialogFragment.newInstance(30).show(getSupportFragmentManager(), "dialog");
 * </pre>
 */
public class ScanDialogFragment extends BottomSheetDialogFragment implements DecoratedBarcodeView.TorchListener {

    private FragmentScanDialogBinding binding;
    private DecoratedBarcodeView barcodeView;
    private BeepManager beepManager;
    private boolean flashOn = false;
    private ImageView btnFlash;
    private ScanListener listener;

    private final BarcodeCallback callback = new BarcodeCallback() {
        @Override
        public void barcodeResult(BarcodeResult result) {
            setResult(result);
        }

        @Override
        public void possibleResultPoints(List<ResultPoint> resultPoints) {
        }
    };

    public ScanDialogFragment(ScanListener listener) {
        this.listener = listener;
    }

    public static ScanDialogFragment newInstance(ScanListener listener) {
        return new ScanDialogFragment(listener);
    }

    private void setResult(BarcodeResult result) {
        listener.scanCallback(result.getText());
        this.dismiss();
    }

    @Nullable
    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentScanDialogBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        barcodeView = binding.barcodeScanner;
        btnFlash = binding.flash;
        btnFlash.setOnClickListener(v -> switchFlashlight());
        Collection<BarcodeFormat> formats = Arrays.asList(BarcodeFormat.QR_CODE, BarcodeFormat.CODE_39, BarcodeFormat.CODE_128);
        barcodeView.getBarcodeView().setDecoderFactory(new DefaultDecoderFactory(formats));
        barcodeView.initializeFromIntent(requireActivity().getIntent());
        barcodeView.decodeContinuous(callback);
        barcodeView.setStatusText("Arahkan kamera ke barcode");
        barcodeView.setTorchListener(this);
        beepManager = new BeepManager(requireActivity());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onTorchOn() {
        btnFlash.setImageResource(R.drawable.ic_flash_on_black_24dp);
    }

    @Override
    public void onTorchOff() {
        btnFlash.setImageResource(R.drawable.ic_flash_off_black_24dp);
    }

    @Override
    public void onResume() {
        super.onResume();
        barcodeView.resume();
    }

    @Override
    public void onPause() {
        super.onPause();
        barcodeView.pauseAndWait();
    }

    public void switchFlashlight() {
        if (!flashOn) {
            flashOn = true;
            barcodeView.setTorchOn();
        } else {
            flashOn = false;
            barcodeView.setTorchOff();
        }
    }

    public interface ScanListener {
        void scanCallback(String result);
    }
}