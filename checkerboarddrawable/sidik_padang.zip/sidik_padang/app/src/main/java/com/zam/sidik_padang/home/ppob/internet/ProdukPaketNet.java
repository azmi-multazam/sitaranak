package com.zam.sidik_padang.home.ppob.internet;

public class ProdukPaketNet {
    public String id = "", code = "", produk = "";

    @Override
    public String toString() {
        return produk;
    }


}

/*
{"produk_paket_net":[{"id":"4",
					  "code":"AXD",
					  "produk":"AXIS INTERNET"}
					  
					  ,{"id":"9","code":"IDN","produk":"INDOSAT INTERNET"},{"id":"10","code":"IDX","produk":"INDOSAT INTERNET EXTRA"},
*/
