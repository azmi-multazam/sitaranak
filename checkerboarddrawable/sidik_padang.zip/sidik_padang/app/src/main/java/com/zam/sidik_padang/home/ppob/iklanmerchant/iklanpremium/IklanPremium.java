package com.zam.sidik_padang.home.ppob.iklanmerchant.iklanpremium;

import java.io.Serializable;

public class IklanPremium implements Serializable {
    public String id, toko, gambar, keterangan;
}

/*
{"merchent_premium":[
	{"id":"2",
	 "toko":"Anis Toko Bunga",
	 "gambar":"http:\/\/berkahbsm.com\/asset\/foto_merchent\/anis.jpg",
	 "keterangan":"Bunga Manis , cantik silahkan di pilih"},{"id":"1","toko":"Toko Mainan","gambar":"http:\/\/berkahbsm.com\/asset\/foto_merchent\/2asemka8.jpg","keterangan":"Sayang Anak , sayang anak silahkan dipilih dan bayar dengan saldo PPOB berkah Bersama"}
	 
	 ],
	 "success":true,
	 "message":"berhasil"}
*/
