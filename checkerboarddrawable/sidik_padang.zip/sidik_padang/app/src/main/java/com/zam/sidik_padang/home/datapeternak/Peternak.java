package com.zam.sidik_padang.home.datapeternak;

import java.io.Serializable;

/**
 * Created by supriyadi on 5/10/17.
 */

public class Peternak implements Serializable {
    public String
            id = "-1",
            iduser = "",
            nama = "",
            kelamin = "",
            nama_kelompok = "",
            alamat_kelompok = "",
            Provinsi = "";
}
