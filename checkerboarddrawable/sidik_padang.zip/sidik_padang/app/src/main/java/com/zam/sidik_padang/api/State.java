package com.zam.sidik_padang.api;

public enum State {
    LOADING, SUCCESS, ERROR, FAILURE
}