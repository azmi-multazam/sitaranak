package com.zam.sidik_padang.util.model;

/**
 * Created by supriyadi on 10/2/17.
 */

public class JenisUsaha extends JenisKomoditas {
    @Override
    public String toString() {
        return super.jenis;
    }
}
