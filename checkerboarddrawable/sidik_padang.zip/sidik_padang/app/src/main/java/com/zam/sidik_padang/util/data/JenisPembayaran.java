package com.zam.sidik_padang.util.data;

/**
 * Created by supriyadi on 8/14/17.
 */

public class JenisPembayaran {
    public String id = "",
            code = "",
            produk = "";

    @Override
    public String toString() {
        return produk;
    }
}


