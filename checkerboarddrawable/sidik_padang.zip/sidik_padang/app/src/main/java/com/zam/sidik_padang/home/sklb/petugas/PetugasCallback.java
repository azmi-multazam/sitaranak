package com.zam.sidik_padang.home.sklb.petugas;

public interface PetugasCallback {
    void onEditClicked(String data);

    void onDeleteClicked(String id, String nama);
}
