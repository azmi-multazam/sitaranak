package com.zam.sidik_padang;

import android.os.Bundle;

import androidx.annotation.Nullable;

/**
 * Created by supriyadi on 5/7/17.
 */

public class DataRecordingTernakActivity extends BaseLogedinActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_recording_ternak);
    }
}
