package com.zam.sidik_padang.home.dataternak;

public enum FooterType {
    TYPE_LOADING, TYPE_SUCCESS, TYPE_ERROR
}