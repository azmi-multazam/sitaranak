package com.zam.sidik_padang.home.dataternak.detailternak.riwayat;

/**
 * Created by supriyadi on 11/1/17.
 */

public class Riwayat {
    String id, tanggal, kondisi, keterangan;
}
