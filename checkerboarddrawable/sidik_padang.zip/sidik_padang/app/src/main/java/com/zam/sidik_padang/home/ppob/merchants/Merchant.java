package com.zam.sidik_padang.home.ppob.merchants;

/**
 * Created by supriyadi on 2/18/18.
 */

public class Merchant {
    String id, toko, gambar, keterangan;
}
