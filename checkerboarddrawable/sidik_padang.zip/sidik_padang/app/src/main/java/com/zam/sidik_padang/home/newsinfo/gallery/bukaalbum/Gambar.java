package com.zam.sidik_padang.home.newsinfo.gallery.bukaalbum;

import java.io.Serializable;

/**
 * Created by supriyadi on 3/6/18.
 */

public class Gambar implements Serializable {
    //public String id_gallery,jdl_gallery,gambar,keterangan;
    public String gambar, tanggal;
}
