package com.zam.sidik_padang.home.newsinfo.bukaberita.komentar;

/**
 * Created by supriyadi on 10/12/17.
 */

class Komentar {
    String id, iduser, komentar, tanggal, foto, nama;
}
