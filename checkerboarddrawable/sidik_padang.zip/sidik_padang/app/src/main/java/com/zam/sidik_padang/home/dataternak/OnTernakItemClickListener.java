package com.zam.sidik_padang.home.dataternak;

public interface OnTernakItemClickListener {
    void OnDataTernakItemClick(String id, int position);
    void onItemDeleteButtonClickListener(String id, String nama, int listPosition);
}
