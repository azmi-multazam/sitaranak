package com.zam.sidik_padang.util.model;

import com.zam.sidik_padang.BuildConfig;

public class ConfigPamekasan {
    //ubah jadi false untuk menonaktifkan fungsi debugging
    public static final boolean DEBUG = BuildConfig.DEBUG;

    public static final String BASE_URL = "https://e-rekording.com";
    public static final String BASE_PAMEKASAN = BASE_URL + "/api_pamekasan/";

    public static final String
            URL_LOGO = BASE_PAMEKASAN + "index.php",
            URL_REGISTRATION = BASE_PAMEKASAN + "crud/registration.php",
            URL_LOGIN = BASE_PAMEKASAN + "login.php",//?userid=KS100000&password=123456,
            URL_ALL_NAMA_KELOMPOK_TERNAK = BASE_PAMEKASAN + "nama_kelompok_ternak.php",
            URL_KELOMPOK_TERNAK = BASE_PAMEKASAN + "add_kelompok_ternak.php",
            URL_NAMA_DAERAH = BASE_PAMEKASAN + "kode_daerah.php",
            URL_PROFILE = BASE_PAMEKASAN + "profil.php",
            URL_KOORDINATOR = BASE_PAMEKASAN + "kordinator.php",
            URL_LIHAT_DATA_PETERNAK = BASE_PAMEKASAN + "lihat_datapeternak.php",
            URL_LIHAT_DATA_TERNAK = BASE_PAMEKASAN + "lihat_dataternak.php",
            URl_STATUS_PERNIKAHAN = BASE_PAMEKASAN + "status_pernikahan.php",
            URL_JENIS_KELAMIN = BASE_PAMEKASAN + "jenis_kelamin.php",
            URL_AGAMA = BASE_PAMEKASAN + "agama.php",
            URL_STATUS_PETERNAKAN = BASE_PAMEKASAN + "status_peternakan.php",
            URL_KELOMPOK = BASE_PAMEKASAN + "kelompok.php",
            URL_JENIS_KOMODITAS = BASE_PAMEKASAN + "jenis_komoditas.php",
            URL_JENIS_USAHA = BASE_PAMEKASAN + "jenis_usaha.php",
            URL_NAMA_KELOMPOK = BASE_PAMEKASAN + "nama_kelompok.php",
            URL_PRODUK_TERNAK = BASE_PAMEKASAN + "produk_ternak.php",
            URL_TAMBAH_GAMBAR = BASE_PAMEKASAN + "tambah_gambar.php",
            URL_TAMBAH_IB = BASE_PAMEKASAN + "tambah_ib.php",
            URL_DATA_TERNAK = BASE_PAMEKASAN + "data_ternak.php",
            URL_DAFTAR = BASE_PAMEKASAN + "daftar.php",
            URL_GAMBAR_SAPI = BASE_PAMEKASAN + "gambar_sapi.php",
            URL_JUMLAH_TERNAK = BASE_PAMEKASAN + "jumlah_ternak.php",
            URL_GABUNGAN = BASE_PAMEKASAN + "gabungan.php",
            URL_HITUNG_TERNAK = BASE_PAMEKASAN + "hitung_ternak.php",
            URL_BERITA = BASE_PAMEKASAN + "berita.php";

    //URL_TAMBAH_GAMBAR = "http://192.168.61.1/unggah.php",
    //URL_TAMBAH_GAMBAR = "http://codecrot.com/inyongmobile/upload.php",

    public static final String URL_SALDO = BASE_URL + "/api/saldo.php?",
            URL_PROSES = BASE_URL + "/api/proses.php?",
            URL_HISTORY = BASE_URL + "/api/history.php?",
            URL_BERITA_PPOB = BASE_URL + "/api/berita.php?",
            URL_CEK_MEMBER = BASE_URL + "/api/cekmember.php?",
            URL_DEPOSIT = BASE_URL + "/api/deposit.php?",
            URL_DOWNLINE = BASE_URL + "/api/downline.php?",
            URL_SETING = BASE_URL + "/api/seting.php?",
            URL_BANK = BASE_URL + "/api/bank.php?",
            URL_GALERY = BASE_URL + "/api/galery.php",
            URL_VIDEO = BASE_URL + "/api/video.php",
            URL_PPOB = BASE_URL + "/api/ppob.php?",
            URL_MERCHANT_LIST = BASE_URL + "/api/list_mercent.php?",
            URL_TRX_MERCHANT = BASE_URL + "/api/trx_merchent.php?";

    public static final String PREF_PILIHAN_BANK = "pilihan_bank";

    //http://e-rekording.com/
    public static final String
            PREF_USER_DETAIL_JSON = "user_detail_json",
            PREF_IS_LOGED_IN = "is_loged_in",
            PREF_WAKTU_DAFTAR = "waktu_daftar",
            PREF_USER_ID = "user_id";
    public static final String PREF_NOMOR_HP = "nomor_hp";
    public static final String PREF_NOMOR_CONFIRMED = "nomor_confirmed";
    public static final String PREF_FOTO_TERNAK_ALL_TERSIMPAN = "foto_ternak_all";
    public static final String PREF_SAPIKU_TERSIMPAN = "response_sapiku";


}
