package com.zam.sidik_padang.home.ppob.history.game;

public class HistoryGame {
    public String id = "", produk = "", status = "";
}
