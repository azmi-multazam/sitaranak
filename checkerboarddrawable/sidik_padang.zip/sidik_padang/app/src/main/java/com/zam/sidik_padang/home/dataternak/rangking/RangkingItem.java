package com.zam.sidik_padang.home.dataternak.rangking;

/**
 * Created by supriyadi on 9/10/17.
 */

public class RangkingItem {
    String id_ternak = "", bb_lahir = "";
    /*{"id_ternak":"TQ2000112","bb_lahir":"35"}*/
}
