package com.zam.sidik_padang.home.koordinator;

import java.io.Serializable;

public class Koordinator implements Serializable {
    public String id = "", iduser = "",
            nama = "", nama_kelompok = "",
            alamat_kelompok = "",
            Provinsi = "";
}

/*
id":"7",
"iduser":"KS1000007",
"nama":"Hadi Purnomo",
"nama_kelompok":null,
"alamat_kelompok":null,
"Region":"JAWA TIMUR"
*/
