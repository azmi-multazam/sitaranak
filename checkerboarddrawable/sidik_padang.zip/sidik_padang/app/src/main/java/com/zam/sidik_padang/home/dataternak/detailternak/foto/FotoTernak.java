package com.zam.sidik_padang.home.dataternak.detailternak.foto;

import java.io.Serializable;

/**
 * Created by supriyadi on 10/4/17.
 */

public class FotoTernak implements Serializable {
    public String id, gambar, tanggal;
}
