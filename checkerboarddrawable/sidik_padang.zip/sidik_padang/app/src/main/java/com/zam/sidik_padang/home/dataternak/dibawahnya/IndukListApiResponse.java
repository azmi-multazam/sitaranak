package com.zam.sidik_padang.home.dataternak.dibawahnya;

import java.util.ArrayList;
import java.util.List;

import com.zam.sidik_padang.BaseApiResponse;

/**
 * Created by supriyadi on 4/30/18.
 */

public class IndukListApiResponse extends BaseApiResponse {
    public List<DataTernak> data_induk = new ArrayList<>();
}
