package com.zam.sidik_padang.roodiskusi;

public class Common {

    public static final String EXTRA_GROUP = "extra_group";
    public static final int GROUP_NOTIF_ID = 0;

    public static final class FireStore {
        public static final String GROUPS = "groups";
        public static final String USERS = "users";
    }
}
