package com.zam.sidik_padang.home.ppob.downline;

/**
 * Created by supriyadi on 7/29/17.
 */

public class Downline {
    String id = "", nama = "", userid = "";
}
