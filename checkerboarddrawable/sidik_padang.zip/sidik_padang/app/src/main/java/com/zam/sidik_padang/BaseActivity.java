package com.zam.sidik_padang;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import com.zam.sidik_padang.util.Config;

public class BaseActivity extends AppCompatActivity {
    public boolean isStoped = true;
    protected boolean isResummed = false;
    protected SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
    }


    @Override
    protected void onStart() {
        // TODO: Implement this method
        super.onStart();
        isStoped = false;
    }

    @Override
    protected void onStop() {
        isStoped = true;
        super.onStop();
    }

    @Override
    protected void onResume() {
        // TODO: Implement this method
        super.onResume();
        isResummed = true;
    }

    @Override
    protected void onPause() {
        isResummed = false;
        super.onPause();
    }


    protected void debug(Class<?> cls, String msgs) {
        if (Config.DEBUG) Log.e(cls.getName(), msgs);
    }
}
