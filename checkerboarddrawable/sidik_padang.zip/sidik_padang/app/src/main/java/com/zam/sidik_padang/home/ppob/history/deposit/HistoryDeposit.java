package com.zam.sidik_padang.home.ppob.history.deposit;

public class HistoryDeposit {
    public String id = "", tgl = "", limite = "", bank = "", status = "";
    public long total = 0;

}

/*
{"history_deposit":[{"id":"13",
					 "tgl":"2017-07-01 10:35:21",
					 "limite":"2017-07-02 10:35:21",
					 "bank":"bca",
					 "total":"1000557",
					 "status":"Sukses"}
					 
					 ,{"id":"17","tgl":"2017-07-07 18:10:27","limite":"2017-07-08 18:10:27","bank":"bca","total":"1000704","status":"Sukses"}],"success":true,"message":"berhasil"}
*/
