package com.zam.sidik_padang;

public class ApiResponse {
    public boolean success = false;
    public String message = "Terjadi kesalahan 6373";
}
