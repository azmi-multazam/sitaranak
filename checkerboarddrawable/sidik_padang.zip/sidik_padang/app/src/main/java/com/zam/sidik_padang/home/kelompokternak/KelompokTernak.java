package com.zam.sidik_padang.home.kelompokternak;

import java.io.Serializable;

/**
 * Created by supriyadi on 5/7/17.
 */

public class KelompokTernak implements Serializable {
    public int id_kelompok = -1;
    public String nama_kelompok = "", alamat_kelompok = "", alamat_korwil = "";
}
