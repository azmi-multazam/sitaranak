package com.zam.sidik_padang.home.ppob.komisi;

/**
 * Created by supriyadi on 7/30/17.
 */

public class Komisi {
    String tanggal = "",
            keterangan = "",
            dari = "",
            nama = "",
            id = "";
    double total = 0;
}

/*
{"komisi":[{"id":"7",
		    "tanggal":"2017-08-23 09:20:01",
			"total":"100",
			"keterangan":"S10 085270853067 ",
			"dari":"100001",
			"nama":"Tri Yutikasari"}
			
			,{"id":"7","tanggal":"2017-08-23 11:15:01","total":"100","keterangan":"I10 081533726792 ","dari":"100001","nama":"Tri Yutikasari"}],"success":true,"message":"Sukses"}
*/
