package com.zam.sidik_padang.home.ppob.iklanmerchant.iklanumum;

import java.io.Serializable;

import com.zam.sidik_padang.home.ppob.iklanmerchant.iklanpremium.IklanPremium;

public class IklanUmum extends IklanPremium implements Serializable {
    public String harga = "", kategori, nama = "";
}
