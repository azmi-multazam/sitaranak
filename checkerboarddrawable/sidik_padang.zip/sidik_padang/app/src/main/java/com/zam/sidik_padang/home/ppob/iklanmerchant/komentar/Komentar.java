package com.zam.sidik_padang.home.ppob.iklanmerchant.komentar;

/**
 * Created by supriyadi on 10/12/17.
 */

public class Komentar {
    public String id, iduser, komentar, tanggal, foto, nama;
}
