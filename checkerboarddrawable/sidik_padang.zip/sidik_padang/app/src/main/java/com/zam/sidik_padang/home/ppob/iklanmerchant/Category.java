package com.zam.sidik_padang.home.ppob.iklanmerchant;

public class Category {
    public String id_kategori, kategori;

    @Override
    public String toString() {
        // TODO: Implement this method
        return "" + kategori;
    }

}
