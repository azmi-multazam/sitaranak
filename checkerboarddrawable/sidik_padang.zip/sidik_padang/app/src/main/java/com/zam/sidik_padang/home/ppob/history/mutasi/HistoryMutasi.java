package com.zam.sidik_padang.home.ppob.history.mutasi;

public class HistoryMutasi {

    public String id = "", tanggal = "", kode = "";
    public double debet = 0, kredit = 0;
}

/*
{"mutasi":[{"id":"1093",
            "tanggal":"2017-07-01 10:40:03",
			"kode":"004",
			"debet":"0",
			"kredit":"1000557"},
			
			*/
