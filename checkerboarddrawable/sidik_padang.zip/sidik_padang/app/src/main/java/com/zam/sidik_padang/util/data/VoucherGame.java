package com.zam.sidik_padang.util.data;

/**
 * Created by supriyadi on 7/9/17.
 */

public class VoucherGame {
    public String id = "", code = "", produk = "";

    @Override
    public String toString() {
        return produk;
    }
}



/*[{"id":"1","code":"GA","produk":"ASIASOFT"},

{"id":"2","code":"BSF","produk":"BSF"},*/