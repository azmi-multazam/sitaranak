package com.zam.sidik_padang.home.sklb.print.hitungscore;

import com.google.gson.Gson;

import java.util.Arrays;

public class KalkulatorScore {

    public static final String[] GRADE_1 = {
            "333",
            "332", "323", "233",
            "331", "313", "133",
    };

    public static final String[] GRADE_2 = {
            "222",
            "223", "232", "322",
            "221", "212", "122",
            "321", "312", "231",
            "213", "123", "132"
    };

    public static final String[] GRADE_3 = {
            "111",
            "112", "121", "211",
            "113", "131", "311",
            "330", "303", "033",
            "220", "202", "022",
            "110", "101", "011",
            "320", "230", "302",
            "032", "023", "310",
            "130", "301", "031",
            "013", "210", "120",
            "201", "021", "012"
    };
}
