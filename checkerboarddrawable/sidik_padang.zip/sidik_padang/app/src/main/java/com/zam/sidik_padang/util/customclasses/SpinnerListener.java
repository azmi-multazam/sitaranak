package com.zam.sidik_padang.util.customclasses;

import android.view.View;
import android.widget.AdapterView;

/**
 * Created by supriyadi on 5/21/17.
 */

public class SpinnerListener implements AdapterView.OnItemSelectedListener {
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
