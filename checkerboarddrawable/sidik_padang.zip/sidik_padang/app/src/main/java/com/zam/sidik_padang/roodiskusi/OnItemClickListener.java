package com.zam.sidik_padang.roodiskusi;

public interface OnItemClickListener {

    public void onItemClick(Object o, int position);
}
