package com.zam.sidik_padang.home.ppob.history.tagihan;


import com.zam.sidik_padang.home.ppob.history.pulsa.HistoryPulsa;

public class HistoryTagihan extends HistoryPulsa {
    public String
            idpel = "0",
            idtagihan = "0",
            namapel = "",
            periode = "",
            total = "0";


}


/*
{"history_tagihan":[{"id":"47",
					 "produk":"BPJS",
					 "idpel":"0001724232251",
					 "idtagihan":"0",
					 "namapel":"0",
					 "periode":"0",
					 "total":0,
					 "status":"Cek Ulang"
					}
				],"success":true,"message":"berhasil"}
*/

