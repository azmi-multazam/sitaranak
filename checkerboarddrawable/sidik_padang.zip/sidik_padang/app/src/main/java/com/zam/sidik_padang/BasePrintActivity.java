package com.zam.sidik_padang;

/**
 * Created by supriyadi on 3/20/18.
 */

public class BasePrintActivity extends BaseLogedinActivity {

}
